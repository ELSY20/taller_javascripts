window.onload = function () {
  let formulario = document.getElementById("formulario");
  formulario.addEventListener("submit", function (e) {
    e.preventDefault();
    capturarDatos();
  });
}

let ArrayProyectos = [];

function agregarProyecto(nuevoProyecto) {
  ArrayProyectos.push(nuevoProyecto);
  llenaTabla();
}

function llenaTabla() {
  let tabla = document.getElementById("table_body");
  tabla.innerHTML = '';
  let template;
  ArrayProyectos.forEach(function (proyecto) {
    template += `<tr>
      <td>${proyecto.codigo}</td>            
      <td>${proyecto.fecha}</td>
      <td>${proyecto.nombre}</td>
      <td>${proyecto.tipo}</td>
      <td>${proyecto.descripcion}</td>
      <td>
        <button class="btn btn-danger" onclick="eliminarProyecto(${proyecto.codigo})">Eliminar</button>
        <button class="btn btn-info" onclick="editarProyecto(${proyecto.codigo})">Editar</button>
      </td>
    </tr>`;
  });

  tabla.innerHTML += template;
}

function eliminarProyecto(codigo) {
  ArrayProyectos = ArrayProyectos.filter(function (proyecto) {
    return proyecto.codigo !== codigo;
  });
  llenaTabla();
}

function editarProyecto(codigo) {
  let proyecto = ArrayProyectos.find(function (proyecto) {
    return proyecto.codigo === codigo;
  });

  let index = ArrayProyectos.indexOf(proyecto);

  let nombre = prompt("Ingrese el nuevo nombre");
  let tipo = prompt("Ingrese el nuevo tipo");
  let descripcion = prompt("Ingrese la nueva descripcion");
  let fecha = prompt("Ingrese la nueva fecha con el formato yyyy-mm-dd");

  let proyectoObjeto = new Proyecto(
    codigo,
    fecha,
    nombre,
    tipo,
    descripcion
  );

  if (validarProyecto(proyectoObjeto)) {
    ArrayProyectos[index] = proyectoObjeto;
    llenaTabla();
  } else {
    return false;
  }
}


function capturarDatos() {
  var codigoCapturado = parseInt(document.getElementById("codigo").value);
  var fechaCapturado = document.getElementById("fecha").value;
  var nombreCapturado = document.getElementById("nombre").value;
  var tipoCapturado = document.getElementById("tipo").value;
  var descripcionCapturado = document.getElementById("descripcion").value;

  nuevoProyecto = new Proyecto(
    codigoCapturado,
    fechaCapturado,
    nombreCapturado,
    tipoCapturado,
    descripcionCapturado
  );


  if (validarProyecto(nuevoProyecto) && validarCodigo(codigoCapturado)) {
    agregarProyecto(nuevoProyecto);
  } else {
    return false;
  }

}

validarProyecto = function (proyecto) {
  let valido = true;

  let regexFecha = /^(19|20)\d\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])$/;
  let regexNumero = /^[0-9]+$/;

  if (!regexFecha.test(proyecto.fecha)) {
    valido = false;
    alert("Fecha no valida");
  }
  if (!regexNumero.test(proyecto.codigo)) {
    valido = false;
    alert("Codigo no valido");
  }

  return valido;
}

validarCodigo = function (codigo) {
  let valido = true;
  ArrayProyectos.forEach(function (proyecto) {
    if (proyecto.codigo === codigo) {
      valido = false;
      alert("Codigo ya existe");
    }
  });
  return valido;
}

// Clase Proyecto
class Proyecto {
  constructor(codigo, fecha, nombre, tipo, descripcion) {
    this.codigo = codigo;
    this.fecha = fecha;
    this.nombre = nombre;
    this.tipo = tipo;
    this.descripcion = descripcion;
  }

  getCodigo() {
    return this.codigo;
  }

  getFecha() {
    return this.fecha;
  }

  getNombre() {
    return this.nombre;
  }

  getTipo() {
    return this.tipo;
  }

  getDescripcion() {
    return this.descripcion;
  }

  setCodigo(codigo) {
    this.codigo = codigo;
  }

  setFecha(fecha) {
    this.fecha = fecha;
  }

  setNombre(nombre) {
    this.nombre = nombre;
  }

  setTipo(tipo) {
    this.tipo = tipo;
  }

  setDescripcion(descripcion) {
    this.descripcion = descripcion;
  }

  toJSON() {
    return {
      codigo: this.codigo,
      fecha: this.fecha,
      nombre: this.nombre,
      tipo: this.tipo,
      descripcion: this.descripcion
    };
  }
}
